import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View, Image } from 'react-native';

export default function input({ navigation }) {
  const handleLogout = () => {
    navigation.replace('Login');
  };

  return (
    <View style={styles.container}>
      <View style={styles.profileContainer}>
        <Text>Profile</Text>
        <View style={styles.fotoProfilBox}>
         <Image source={require('../assets/md.png')} style={styles.fotoProfilBox} ></Image>
        </View>
        <Text style={styles.namaText}>MUHAMAD MAHPUD ABDULLAH</Text>
      </View>
      <View style={styles.menuGrid}>
        <View style={styles.menuRow}>
          <TouchableOpacity style={styles.menuBox}>
            <Text style={styles.menuText}>MENU 1</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuBox}>
            <Text style={styles.menuText}>MENU 2</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.menuRow}>
          <TouchableOpacity style={styles.menuBox}>
            <Text style={styles.menuText}>MENU 3</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuBox}>
            <Text style={styles.menuText}>MENU 4</Text>
          </TouchableOpacity>
        </View>
      </View>

     
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>TOMBOL LOGOUT</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  profileContainer: {
    alignItems: 'center',
    marginTop: 40,
  },
  fotoProfilBox: {
    width: 200,
    height: 200,
    borderWidth: 1,
    borderColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    marginBottom: 10,
    marginTop: 10
  },
  fotoText: {
    fontSize: 10,
    color: '#555',
    textAlign: 'center',
  },
  namaText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  menuGrid: {
    width: '100%',
    maxWidth: 300,
  },
  menuRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  menuBox: {
    width: '47%',
    height: 50,
    borderWidth: 1,
    borderColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
    backgroundColor: '#f8f8f8',
  },
  menuText: {
    fontWeight: 'bold',
    color: '#333',
  },
  logoutButton: {
    width: '100%',
    maxWidth: 300,
    height: 48,
    borderWidth: 1,
    borderColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 15,
    marginBottom: 20,
    backgroundColor: '#c63131',
  },
  logoutText: {
    fontWeight: 'bold',
    color: '#cac0c0',
  },
});