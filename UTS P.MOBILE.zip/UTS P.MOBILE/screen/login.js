import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, TouchableOpacity, View, Alert } from 'react-native';

export default function login({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (email.trim() === '' || password.trim() === '') {
      Alert.alert('Peringatan', 'Email dan Password tidak boleh kosong!');
      return;
    }
    
    navigation.replace('MainHome');
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.appTitle}>Selamat Datang di 'appUTS'</Text>
        <Text style={styles.subTitle}>silakan login !!!</Text>
      </View>

      <View style={styles.formContainer}>
        <TextInput
          style={styles.input}
          placeholder="INPUT EMAIL"
          placeholderTextColor="#848484"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
        />

        <TextInput
          style={styles.input}
          placeholder="INPUT PASSWORD"
          placeholderTextColor="#848484"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />

        <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
          <Text style={styles.loginButtonText}>TOMBOL LOGIN</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  headerContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  appTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    letterSpacing: 2,
  },
  subTitle: {
    fontSize: 16,
    color: '#555',
    marginTop: 5,
  },
  formContainer: {
    width: '100%',
    maxWidth: 320,
  },
  input: {
    width: '100%',
    height: 48,
    borderWidth: 1,
    borderColor: '#000000',
    borderRadius: 15,
    paddingHorizontal: 15,
    marginBottom: 15,
    backgroundColor: '#cfd3d4',
  },
  loginButton: {
    width: '100%',
    height: 48,
    borderWidth: 1,
    borderColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 9,
    marginTop: 10,
    backgroundColor: '#21db0d',
  },
  loginButtonText: {
    fontWeight: 'bold',
    color: '#333',
  },
});